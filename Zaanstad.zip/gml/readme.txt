Ontbrekende gml-en:
- 007_beperkingengebied_buisleiding_voor_gevaarlijke_stoffen.gml (b14e30e9-75d8-4a96-a448-d66ff7236e1b)
- 008_beperkingengebied_hoogspanningsverbinding.gml (7b18816f-f5a7-45b5-b63e-47ca3a17c094)
- 009_beperkingengebied_magneetveldzone.gml (092dd093-5534-4868-a881-7dc8c56aeff2)
- 010_beperkingengebied_waterkering.gml (2a1152af-084a-48c3-a99d-4f22bf33f82f)

Volgende gml-en aanpassen:
- 001_gemeente_Zaanstad.gml (2eafad5c-98c2-4bff-867d-670f9d969224)
- 002_gebiedstype_woongebied_variant_1.gml (15a3b0a5-ecd2-48ef-abd3-efa29b01404e)
- 003_gebiedstype_woongebied_variant_2.gml (d3175fcb-dc25-4c38-8937-b501f1082966)
- 004_welstandsgebied.gml (18446068-e0bc-4b21-89d3-90cbab00968c)
- 005_Verplichte_aanleg_van_groen.gml (86a432ce-ef24-48d2-b8af-2602dab9586e)
- 006_Verplichte_aanleg_van_water.gml (3bf96433-9b6d-4827-ac89-58f6efaa91a0)