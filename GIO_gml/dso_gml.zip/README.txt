Kopieer de inhoud van deze zip naar (eventueel folder aanmaken):
    {gebruiker}/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins/dso_gml

Bij initiele installatie:
Start QGIS en activeer plugin in plugin manager

Bij update:
(Her)start QGIS